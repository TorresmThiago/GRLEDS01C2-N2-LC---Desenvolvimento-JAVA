package Exceptions;

public class NomeInvalidoException extends Exception {

    public NomeInvalidoException(String message) {
        super(message);
    }
}