package Exceptions;

public class NotaInvalidaException extends Exception {

    public NotaInvalidaException(String message) {
        super(message);
    }
}
